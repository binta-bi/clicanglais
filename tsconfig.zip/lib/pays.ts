// Pays proposés pour le numéro WhatsApp : [code ISO, nom, indicatif]
// Liste triée par ordre alphabétique (français) ; la Côte d'Ivoire reste sélectionnée par défaut dans le formulaire.
export type Pays = { iso: string; nom: string; indicatif: string }

const LISTE: [string, string, string][] = [
  ['CI', 'Côte d’Ivoire', '225'],
  ['GN', 'Guinée', '224'],
  ['SN', 'Sénégal', '221'],
  ['ML', 'Mali', '223'],
  ['BF', 'Burkina Faso', '226'],
  ['BJ', 'Bénin', '229'],
  ['TG', 'Togo', '228'],
  ['NE', 'Niger', '227'],
  ['GH', 'Ghana', '233'],
  ['NG', 'Nigeria', '234'],
  ['LR', 'Liberia', '231'],
  ['SL', 'Sierra Leone', '232'],
  ['GM', 'Gambie', '220'],
  ['GW', 'Guinée-Bissau', '245'],
  ['CV', 'Cap-Vert', '238'],
  ['MR', 'Mauritanie', '222'],
  ['CM', 'Cameroun', '237'],
  ['GA', 'Gabon', '241'],
  ['CG', 'Congo', '242'],
  ['CD', 'RD Congo', '243'],
  ['TD', 'Tchad', '235'],
  ['CF', 'Centrafrique', '236'],
  ['GQ', 'Guinée équatoriale', '240'],
  ['ST', 'São Tomé-et-Príncipe', '239'],
  ['AO', 'Angola', '244'],
  ['BI', 'Burundi', '257'],
  ['RW', 'Rwanda', '250'],
  ['DJ', 'Djibouti', '253'],
  ['KM', 'Comores', '269'],
  ['MG', 'Madagascar', '261'],
  ['KE', 'Kenya', '254'],
  ['ET', 'Éthiopie', '251'],
  ['ZA', 'Afrique du Sud', '27'],
  ['MA', 'Maroc', '212'],
  ['DZ', 'Algérie', '213'],
  ['TN', 'Tunisie', '216'],
  ['EG', 'Égypte', '20'],
  ['FR', 'France', '33'],
  ['BE', 'Belgique', '32'],
  ['CH', 'Suisse', '41'],
  ['LU', 'Luxembourg', '352'],
  ['DE', 'Allemagne', '49'],
  ['GB', 'Royaume-Uni', '44'],
  ['ES', 'Espagne', '34'],
  ['IT', 'Italie', '39'],
  ['PT', 'Portugal', '351'],
  ['NL', 'Pays-Bas', '31'],
  ['CA', 'Canada', '1'],
  ['US', 'États-Unis', '1'],
  ['HT', 'Haïti', '509'],
  ['BR', 'Brésil', '55'],
  ['AE', 'Émirats arabes unis', '971'],
  ['SA', 'Arabie saoudite', '966'],
  ['LB', 'Liban', '961'],
  ['TR', 'Turquie', '90'],
  ['CN', 'Chine', '86'],
  ['IN', 'Inde', '91'],
]

export const PAYS: Pays[] = LISTE.map(([iso, nom, indicatif]) => ({ iso, nom, indicatif })).sort((a, b) =>
  a.nom.localeCompare(b.nom, 'fr')
)

// Drapeau en emoji à partir du code ISO (ex. CI -> 🇨🇮)
export const drapeau = (iso: string) =>
  String.fromCodePoint(...iso.split('').map((c) => 0x1f1e6 + c.charCodeAt(0) - 65))
